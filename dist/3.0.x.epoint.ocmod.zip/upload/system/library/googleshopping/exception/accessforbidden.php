<?php

namespace googleshopping\Exception;

class AccessForbidden extends \RuntimeException {
}
